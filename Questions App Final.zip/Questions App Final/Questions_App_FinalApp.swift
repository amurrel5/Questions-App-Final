//
//  Questions_App_FinalApp.swift
//  Questions App Final
//
//  Created by scholar on 5/31/23.
//

import SwiftUI

@main
struct Questions_App_FinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
